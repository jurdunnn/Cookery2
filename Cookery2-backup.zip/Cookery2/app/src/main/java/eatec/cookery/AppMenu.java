package eatec.cookery;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
/*Unused class - possible deletion, generated when side menu
* was used during early stages of the project.*/
public class AppMenu extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_app);
    }
}
